package uz.xsoft.lesson16pdp11

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.item_contact.view.*
import kotlinx.android.synthetic.main.layout_toast.view.*
import uz.xsoft.lesson16pdp11.models.ContactData
import java.text.FieldPosition

class MainActivity : AppCompatActivity() {
    private val data = ArrayList<ContactData>()
    private val adapter = ContactAdapter(data)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        loadData()
        list.adapter = adapter
        list.onItemClickListener = object : AdapterView.OnItemClickListener {
            override fun onItemClick(root: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val d = data[position]
                val t = Toast(this@MainActivity)
                val v = LayoutInflater.from(this@MainActivity)
                    .inflate(R.layout.layout_toast, null, false)
                v.textTitle.text = d.name
                t.view = v
                t.duration = Toast.LENGTH_SHORT
                t.show()
            }

        }
        /*val t = Toast(this)
        val v = LayoutInflater.from(this).inflate(R.layout.item_contact, null, false)
        v.textName.text = "Salom"
        t.view = v
        t.duration = Toast.LENGTH_LONG
        t.show()*/
    }

    private fun loadData() {
        for (i in 1..100) {
            data.add(ContactData(R.drawable.image1,"Alisa $i", "+998911234567"))
            data.add(ContactData(R.drawable.image2,"Alisa $i", "+998911234567"))
            data.add(ContactData(R.drawable.image3,"Alisa $i", "+998911234567"))
        }
        data.shuffle()
    }
}
