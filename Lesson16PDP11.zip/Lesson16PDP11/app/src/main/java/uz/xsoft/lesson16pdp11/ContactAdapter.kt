package uz.xsoft.lesson16pdp11

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.item_contact.view.*
import uz.xsoft.lesson16pdp11.models.ContactData

class ContactAdapter(val data: ArrayList<ContactData>) : BaseAdapter() {
    @SuppressLint("ViewHolder")
    override fun getView(postion: Int, view: View?, root: ViewGroup): View {
        val v = LayoutInflater.from(root.context)
            .inflate(R.layout.item_contact, root, false)
        val d = getItem(postion)
        v.textName.text = d.name
        v.textPhone.text = d.phone
        v.imageIcon.setImageResource(d.image)
        return v
    }

    override fun getItem(postion: Int) = data[postion]

    override fun getItemId(postion: Int) = 0L

    override fun getCount(): Int = data.size

}