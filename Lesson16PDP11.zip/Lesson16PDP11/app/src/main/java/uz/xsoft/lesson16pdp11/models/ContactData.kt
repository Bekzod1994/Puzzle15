package uz.xsoft.lesson16pdp11.models

data class ContactData(
    val image:Int,
    val name: String,
    val phone: String
)